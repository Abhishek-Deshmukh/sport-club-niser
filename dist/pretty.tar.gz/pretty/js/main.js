// Place your content here🐶
var message = "Hello World!";
console.log(message);
